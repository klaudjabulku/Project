package Entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Setter
@Getter
@Entity
@Table(name="room")
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Integer id;

    @Column(name="room_type")
    private String roomType;

    @Column(name="room_capacity")
    private int roomCapacity;

    @Column(name="price")
    private double price;

    @Column(name="availability")
    private boolean availability;

    @Column(name="check_in_date")
    private Date checkInDate;

    @Column(name="check_out_date")
    private Date checkOutDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;

    public Room(String single, int i, double v, boolean b, Date date, Hotel hotel) {

    }

    public Room(String roomType, int roomCapacity, double price, boolean availability, Date checkInDate, Date checkOutDate, Hotel hotel) {
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.price = price;
        this.availability = availability;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.hotel = hotel;
    }

    @Override
    public String toString() {
        return "Room{" +
                "id=" + id +
                ", roomType='" + roomType + '\'' +
                ", roomCapacity=" + roomCapacity +
                ", price=" + price +
                ", availability=" + availability +
                ", checkInDate=" + checkInDate +
                ", checkOutDate=" + checkOutDate +
                '}';
    }

    public void setDates(Date dates) {

    }
}
