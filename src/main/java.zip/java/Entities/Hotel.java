package Entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@Entity
@Table(name="hotel")
public class Hotel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Integer id;

    @Column(name="name")
    private String name;

    @Column(name="location")
    private String location;

    @Column(name="number_of_rooms")
    private int numberOfRooms;

    @OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
    private List<Room> rooms = new ArrayList<>();

    public Hotel(String testHotel, String testLocation, int i) {}

    public Hotel(String single, String name, String location, int numberOfRooms) {
        this.name = name;
        this.location = location;
        this.numberOfRooms = numberOfRooms;
    }

    @Override
    public String toString() {
        return "Hotel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", numberOfRooms=" + numberOfRooms +
                '}';
    }
}
