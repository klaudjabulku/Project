package Entities;

import Strategy.DiscountedPricingStrategy;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RoomBookingSystemTest {

    public static void main(String[] args) {
        Customer customer = new Customer("Klaudja", "Bulku", "klaudja@yahoo.com", "123456789", null);
        Hotel hotel = new Hotel("Test Hotel", "Test Location", 10);
        Room room = new Room("Single", 1, 100.0, true, new Date(), hotel);
        Date checkInDate = new Date();
        Date checkOutDate = new Date(checkInDate.getTime() + (1000 * 60 * 60 * 24 * 3)); // Check-out date is 3 days from check-in


        RoomBookingSystem roomBookingSystem = new RoomBookingSystem();
        boolean isAvailable = roomBookingSystem.isRoomAvailable(hotel, checkInDate, checkOutDate, "Single");
        System.out.println("Room available: " + isAvailable);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        try {
            checkInDate = dateFormat.parse("2024-04-24");
            checkOutDate = dateFormat.parse("2024-04-29");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        RoomBookingSystem RoomBookingSystem = new RoomBookingSystem();
        RoomBookingSystem.setPricingStrategy(new DiscountedPricingStrategy() {

            @Override
            public double calculatePrice(Room room, java.util.Date checkInDate, java.util.Date checkOutDate) {
                return 0;
            }
        });


        boolean isRoomAvailable = RoomBookingSystem.isRoomAvailable(hotel, checkInDate, checkOutDate, "Single");
        System.out.println("Is room available: " + isRoomAvailable);

        if (isRoomAvailable) {
            RoomBookingSystem.bookRoom(customer, hotel, room, checkInDate, checkOutDate, 1, "klaudiabulku@yahoo.com", "123456789");
        } else {
            System.out.println("Room is not available for booking.");
        }
    }
}
