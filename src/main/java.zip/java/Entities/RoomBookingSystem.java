package Entities;

import Repository.CustomerRepository;
import Repository.RoomRepository;
import Strategy.PricingStrategy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RoomBookingSystem {

    private PricingStrategy pricingStrategy;
    private RoomRepository roomRepository;
    private CustomerRepository customerRepository;

    public RoomBookingSystem() {
        this.roomRepository = new RoomRepository();
        this.customerRepository = new CustomerRepository();
    }

    public boolean isRoomAvailable(Hotel hotel, Date checkInDate, Date checkOutDate, String roomType) {
        for (Room room : hotel.getRooms()) {
            if (room.getRoomType().equals(roomType) && room.isAvailability() &&
                    room.getCheckInDate().before(checkOutDate) && room.getCheckOutDate().after(checkInDate)) {
                return true;
            }
        }
        return false;
    }

    public double getPricePerDay(Room room, Date checkInDate, Date checkOutDate) {
        if (pricingStrategy != null) {
            return pricingStrategy.calculatePrice(room, checkInDate, checkOutDate);
        } else {
            return room.getPrice();
        }
    }

    public void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    public void bookRoom(Customer customer, Hotel hotel, Room room, Date checkInDate, Date checkOutDate, int numberOfPeople, String emailAddress, String phoneNumber) {
        if (isRoomAvailable(hotel, checkInDate, checkOutDate, room.getRoomType())) {
            long diff = checkOutDate.getTime() - checkInDate.getTime();
            int numberOfNights = (int) (diff / (1000 * 60 * 60 * 24));

            double totalPrice = numberOfNights * getPricePerDay(room, checkInDate, checkOutDate);

            String bookingConfirmation = "Booking Confirmation:\n\n" +
                    "Hotel Name: " + hotel.getName() + "\n" +
                    "Room Type: " + room.getRoomType() + "\n" +
                    "Check-in Date: " + formatDate(checkInDate) + "\n" +
                    "Check-out Date: " + formatDate(checkOutDate) + "\n" +
                    "Name: " + customer.getName() + " " + customer.getSurname() + "\n" +
                    "Number of People: " + numberOfPeople + "\n" +
                    "Email Address: " + emailAddress + "\n" +
                    "Phone Number: " + phoneNumber + "\n" +
                    "Price of Reservation: EUR " + totalPrice;

            writeBookingConfirmationToFile(customer.getName(), bookingConfirmation);

            room.setAvailability(false);
        } else {
            System.out.println("Sorry, the room is not available for the specified dates.");
        }
    }

    private void writeBookingConfirmationToFile(String customerName, String bookingConfirmation) {
        String fileName = customerName + "_Booking_Confirmation.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(bookingConfirmation);
            System.out.println("Booking confirmation has been written to file: " + fileName);
        } catch (IOException e) {
            System.err.println("Error writing booking confirmation to file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        return sdf.format(date);
    }
}
